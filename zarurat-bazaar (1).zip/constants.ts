import { Branch, Category, Product, Service } from "./types";

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Groceries', icon: 'carrot', slug: 'groceries' },
  { id: '2', name: 'Clothing', icon: 'shirt', slug: 'clothing' },
  { id: '3', name: 'Electronics', icon: 'smartphone', slug: 'electronics' },
  { id: '4', name: 'Furniture', icon: 'armchair', slug: 'furniture' },
  { id: '5', name: 'Services', icon: 'wrench', slug: 'services' },
  { id: '6', name: 'Automobiles', icon: 'car', slug: 'automobiles' },
  { id: '7', name: 'Daily Needs', icon: 'shopping-bag', slug: 'daily-needs' },
  { id: '8', name: 'Hardware', icon: 'hammer', slug: 'hardware' },
];

export const BRANCHES: Branch[] = [
  { id: 'b1', name: 'Malviya Nagar HQ', address: 'Malviya Nagar, New Delhi, 110017', coordinates: { lat: 28.5355, lng: 77.2100 }, phone: '+91-11-23456789' },
  { id: 'b2', name: 'Saket Branch', address: 'Saket District Centre, New Delhi', coordinates: { lat: 28.5245, lng: 77.2180 }, phone: '+91-11-98765432' },
  { id: 'b3', name: 'Hauz Khas Store', address: 'Hauz Khas Market, New Delhi', coordinates: { lat: 28.5494, lng: 77.1990 }, phone: '+91-11-11223344' },
];

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Organic Basmati Rice (5kg)',
    category: 'groceries',
    price: 850,
    originalPrice: 1100,
    image: 'https://picsum.photos/400/400?random=1',
    rating: 4.8,
    reviews: 124,
    stock: 50,
    description: 'Premium aged basmati rice, perfect for biryani and daily meals.',
    isNew: true
  },
  {
    id: 'p2',
    name: 'Smart LED TV 55"',
    category: 'electronics',
    price: 34999,
    originalPrice: 45000,
    image: 'https://picsum.photos/400/400?random=2',
    rating: 4.5,
    reviews: 89,
    stock: 10,
    description: '4K Ultra HD Smart LED TV with Dolby Audio and Voice Control.',
    isNew: true
  },
  {
    id: 'p3',
    name: 'Men\'s Cotton Shirt',
    category: 'clothing',
    price: 799,
    originalPrice: 1499,
    image: 'https://picsum.photos/400/400?random=3',
    rating: 4.2,
    reviews: 45,
    stock: 100,
    description: '100% Cotton slim-fit formal shirt.',
  },
  {
    id: 'p4',
    name: 'Wooden Coffee Table (Used)',
    category: 'furniture',
    price: 2500,
    originalPrice: 8000,
    image: 'https://picsum.photos/400/400?random=4',
    rating: 3.8,
    reviews: 12,
    stock: 1,
    description: 'Solid wood coffee table, 2 years old, good condition.',
    isUsed: true
  },
  {
    id: 'p5',
    name: 'Wireless Headphones',
    category: 'electronics',
    price: 1999,
    originalPrice: 3999,
    image: 'https://picsum.photos/400/400?random=5',
    rating: 4.6,
    reviews: 230,
    stock: 25,
    description: 'Noise cancelling over-ear headphones with 20h battery life.',
  },
  {
    id: 'p6',
    name: 'Fresh Apples (1kg)',
    category: 'groceries',
    price: 180,
    image: 'https://picsum.photos/400/400?random=6',
    rating: 4.9,
    reviews: 56,
    stock: 200,
    description: 'Farm fresh Kashmiri apples.',
  }
];

export const SERVICES: Service[] = [
  {
    id: 's1',
    name: 'Electrician',
    category: 'repair',
    priceStart: 299,
    image: 'https://picsum.photos/400/300?random=10',
    description: 'Wiring, fan installation, switch repair, and more.'
  },
  {
    id: 's2',
    name: 'Plumber',
    category: 'repair',
    priceStart: 349,
    image: 'https://picsum.photos/400/300?random=11',
    description: 'Leak repair, tap installation, pipe fitting.'
  },
  {
    id: 's3',
    name: 'AC Service',
    category: 'appliance',
    priceStart: 599,
    image: 'https://picsum.photos/400/300?random=12',
    description: 'Deep cleaning and gas refilling for Split/Window AC.'
  }
];