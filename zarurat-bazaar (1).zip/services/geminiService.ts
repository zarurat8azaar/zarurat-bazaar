import { GoogleGenAI, Type, SchemaType } from "@google/genai";
import { PRODUCTS, SERVICES, BRANCHES } from "../constants";

let ai: GoogleGenAI | null = null;

const initializeAI = () => {
  if (!ai && process.env.API_KEY) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
};

const CHAT_SYSTEM_INSTRUCTION = `
You are 'Zara', the intelligent shopping assistant for Zarurat Bazaar, a hybrid supermarket in New Delhi.
Your goal is to help customers find products, book services, check policies, and locate stores.

Key Information:
- We sell Groceries, Electronics, Clothing, Furniture (New & Used), etc.
- We offer Services like Electricians and Plumbers.
- We have physical branches in Malviya Nagar, Saket, and Hauz Khas.
- Customers can buy online or pickup in-store.

Policies:
- Returns: 7-day return policy for unused items with original tags. No returns on perishable groceries.
- Payments: We accept Credit/Debit Cards, UPI, and Cash on Delivery.
- Delivery: Standard delivery is ₹49. Free delivery on orders above ₹1000. Express delivery within 2 hours.

Catalog Summary:
Products: ${PRODUCTS.map(p => `${p.name} (ID: ${p.id})`).join(', ')}
Services: ${SERVICES.map(s => s.name).join(', ')}

Rules:
1. Be polite, helpful, and concise (under 100 words).
2. If asking for order status: Ask for the Order ID. If an ID is provided (e.g., #ORD...), simulate a status check and say "Your order is currently Out for Delivery and will reach you by 6 PM today."
3. If asking for store location, list our branches.
4. If asked to recommend products, suggest specific items from our catalog.
`;

export const getChatResponse = async (userMessage: string): Promise<string> => {
  try {
    initializeAI();
    if (!ai) {
      return "I'm currently offline (API Key missing). Please check the console or try again later.";
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userMessage,
      config: {
        systemInstruction: CHAT_SYSTEM_INSTRUCTION,
      },
    });

    return response.text || "I'm not sure how to help with that.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my brain right now. Please try again.";
  }
};

export const getProductRecommendations = async (context: string, currentProductIds: string[] = []): Promise<string[]> => {
  try {
    initializeAI();
    if (!ai) return [];

    const prompt = `
      Analyze the following user context: "${context}".
      
      Based on this context and the available product catalog below, select 4 distinct Product IDs that the user would most likely be interested in.
      Do not recommend products with these IDs: ${currentProductIds.join(', ')}.
      
      Product Catalog:
      ${JSON.stringify(PRODUCTS.map(p => ({ id: p.id, name: p.name, category: p.category, description: p.description })))}
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          }
        }
      }
    });

    const jsonText = response.text || "[]";
    const recommendedIds = JSON.parse(jsonText);
    
    // Validate that the returned IDs actually exist in our catalog
    return recommendedIds.filter((id: string) => PRODUCTS.some(p => p.id === id));

  } catch (error) {
    console.error("Gemini Recommendation Error:", error);
    // Fallback to random products if AI fails
    return PRODUCTS.slice(0, 4).map(p => p.id);
  }
};