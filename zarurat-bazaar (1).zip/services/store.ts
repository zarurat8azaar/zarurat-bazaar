import React, { createContext, useContext, useState } from 'react';
import { BRANCHES } from '../constants';
import { CartItem, Product, User, Branch } from '../types';

interface AppState {
  user: User | null;
  cart: CartItem[];
  selectedBranch: Branch | null;
  isLoginModalOpen: boolean;
  
  // Actions
  login: (email: string) => void;
  logout: () => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  setBranch: (branch: Branch) => void;
  toggleLoginModal: (isOpen: boolean) => void;
  cartTotal: number;
}

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(BRANCHES[0]);
  const [isLoginModalOpen, setLoginModalOpen] = useState(false);

  const login = (email: string) => {
    // Mock login
    setUser({
      id: 'u1',
      name: 'Demo User',
      email,
      role: 'customer',
      addresses: [{ id: 'a1', label: 'Home', details: 'B-12, Malviya Nagar, Delhi' }]
    });
    setLoginModalOpen(false);
  };

  const logout = () => {
    setUser(null);
    setCart([]);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => item.id === productId ? { ...item, quantity } : item));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return React.createElement(AppContext.Provider, {
    value: {
      user, cart, selectedBranch, isLoginModalOpen,
      login, logout, addToCart, removeFromCart, updateQuantity, setBranch: setSelectedBranch, toggleLoginModal: setLoginModalOpen,
      cartTotal
    }
  }, children);
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};