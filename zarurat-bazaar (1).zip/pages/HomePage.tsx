import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, Store, ShieldCheck, Clock } from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import RecommendationSection from '../components/RecommendationSection';

const HomePage = () => {
  const featuredProducts = PRODUCTS.slice(0, 4);

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative bg-brand-green text-white overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 space-y-6">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Grocery, Electronics <br/> & Services <br/>
              <span className="text-brand-orange">All in One Place</span>
            </h1>
            <p className="text-lg opacity-90">
              Shop from home or pick up from our store. Book services instantly.
              The smartest way to shop in New Delhi.
            </p>
            <div className="flex gap-4">
              <Link to="/shop" className="bg-brand-orange hover:bg-brand-darkOrange text-white px-8 py-3 rounded-lg font-semibold transition-colors">
                Shop Now
              </Link>
              <Link to="/services" className="bg-white/20 hover:bg-white/30 backdrop-blur text-white px-8 py-3 rounded-lg font-semibold transition-colors">
                Book Services
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
             {/* Abstract Illustration Placeholder */}
             <img 
               src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=1000" 
               alt="Supermarket" 
               className="rounded-2xl shadow-2xl w-full max-w-md object-cover h-80 transform rotate-2 hover:rotate-0 transition-transform duration-500"
             />
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          {[
            { icon: Truck, title: 'Home Delivery', desc: 'Within 2 hours' },
            { icon: Store, title: 'Store Pickup', desc: 'From nearby branch' },
            { icon: ShieldCheck, title: 'Quality Assurance', desc: 'Verified products' },
            { icon: Clock, title: '24/7 Support', desc: 'Always here for you' },
          ].map((feature, idx) => (
            <div key={idx} className="flex items-center gap-4 p-2">
              <div className="bg-brand-green/10 p-3 rounded-full text-brand-green">
                <feature.icon size={24} />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 text-sm md:text-base">{feature.title}</h4>
                <p className="text-xs text-gray-500">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories Grid */}
      <section className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex justify-between items-center">
          Shop by Category
          <Link to="/shop" className="text-brand-green text-sm font-medium flex items-center hover:underline">
            View All <ArrowRight size={16} className="ml-1" />
          </Link>
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {CATEGORIES.map(cat => (
            <Link key={cat.id} to={`/shop?category=${cat.slug}`} className="flex flex-col items-center p-4 bg-white border border-gray-100 rounded-xl hover:shadow-md transition-all hover:border-brand-green group">
              <div className="w-12 h-12 mb-3 bg-gray-50 rounded-full flex items-center justify-center text-gray-600 group-hover:bg-brand-green group-hover:text-white transition-colors">
                <img src={`https://api.iconify.design/lucide:${cat.icon}.svg`} alt="" className="w-6 h-6 opacity-80 group-hover:invert filter" />
              </div>
              <span className="text-sm font-medium text-gray-700 text-center">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Trending Now</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* AI Recommendations */}
      <section className="container mx-auto px-4">
        <RecommendationSection 
          context="User is on the homepage. Suggest a mix of daily essentials, electronics, and clothing suitable for a general customer in New Delhi."
        />
      </section>

      {/* Banner */}
      <section className="container mx-auto px-4">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 text-center md:text-left relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl font-bold text-white mb-4">Sell Your Used Items</h2>
            <p className="text-gray-300 mb-6 max-w-xl">
              Turn your old furniture and electronics into cash. List your products on Zarurat Bazaar today.
            </p>
            <button className="bg-white text-gray-900 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Coming Soon
            </button>
          </div>
          {/* Decorative Circle */}
          <div className="absolute -right-20 -bottom-40 w-80 h-80 bg-brand-orange rounded-full opacity-20 blur-3xl"></div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;