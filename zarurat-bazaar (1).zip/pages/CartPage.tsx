import React, { useState } from 'react';
import { useApp } from '../services/store';
import { Trash2, Plus, Minus, Store, Truck } from 'lucide-react';
import { Link } from 'react-router-dom';
import RecommendationSection from '../components/RecommendationSection';

const CartPage = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal, selectedBranch } = useApp();
  const [deliveryMode, setDeliveryMode] = useState<'delivery' | 'pickup'>('delivery');

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added anything yet.</p>
        <Link to="/shop" className="bg-brand-green text-white px-8 py-3 rounded-lg font-medium hover:bg-brand-lightGreen">
          Start Shopping
        </Link>
        
        <div className="mt-16 text-left">
          <RecommendationSection 
            title="Trending Right Now" 
            context="User has an empty cart. Suggest 4 popular, high-rated items from different categories (Electronics, Groceries, Clothing) to get them started." 
          />
        </div>
      </div>
    );
  }

  const deliveryFee = deliveryMode === 'delivery' ? 49 : 0;
  const finalTotal = cartTotal + deliveryFee;

  // Create context string from cart items for the AI
  const cartContext = `User has these items in cart: ${cart.map(i => `${i.name} (${i.category})`).join(', ')}. Suggest complementary products or accessories that go well with these.`;
  const cartIds = cart.map(i => i.id);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Shopping Cart</h1>
      
      <div className="flex flex-col lg:flex-row gap-8 mb-12">
        {/* Cart Items */}
        <div className="lg:w-2/3 space-y-4">
          {cart.map(item => (
            <div key={item.id} className="flex gap-4 bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
              <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{item.name}</h3>
                  <p className="text-sm text-gray-500 capitalize">{item.category}</p>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full border flex items-center justify-center hover:bg-gray-50"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="font-medium w-4 text-center">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full border flex items-center justify-center hover:bg-gray-50"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-bold text-lg">₹{item.price * item.quantity}</span>
                    <button 
                      onClick={() => removeFromCart(item.id)} 
                      className="text-red-500 hover:text-red-600 p-2"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Checkout Sidebar */}
        <div className="lg:w-1/3">
          <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm sticky top-24">
            <h3 className="font-bold text-lg mb-4">Order Summary</h3>
            
            {/* Delivery Toggle */}
            <div className="flex bg-gray-100 p-1 rounded-lg mb-6">
              <button 
                onClick={() => setDeliveryMode('delivery')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-md transition-all ${deliveryMode === 'delivery' ? 'bg-white shadow text-brand-green' : 'text-gray-500'}`}
              >
                <Truck size={16} /> Delivery
              </button>
              <button 
                onClick={() => setDeliveryMode('pickup')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-md transition-all ${deliveryMode === 'pickup' ? 'bg-white shadow text-brand-green' : 'text-gray-500'}`}
              >
                <Store size={16} /> Pickup
              </button>
            </div>

            {deliveryMode === 'pickup' && (
              <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg mb-6 text-xs text-yellow-800">
                <span className="font-bold block mb-1">Pickup Location:</span>
                {selectedBranch?.name}, {selectedBranch?.address}
              </div>
            )}

            <div className="space-y-3 text-sm text-gray-600 mb-6">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{cartTotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>{deliveryFee === 0 ? <span className="text-green-600">Free</span> : `₹${deliveryFee}`}</span>
              </div>
              <div className="flex justify-between font-bold text-gray-900 text-lg border-t pt-3">
                <span>Total</span>
                <span>₹{finalTotal}</span>
              </div>
            </div>

            <button className="w-full bg-brand-green text-white py-3 rounded-lg font-bold hover:bg-brand-lightGreen shadow-lg transition-transform active:scale-95">
              Proceed to Checkout
            </button>
            
            <p className="text-xs text-center text-gray-400 mt-4">
              Secure checkout powered by Razorpay
            </p>
          </div>
        </div>
      </div>

      <RecommendationSection 
        title="You Might Also Like" 
        context={cartContext} 
        excludeIds={cartIds}
      />
    </div>
  );
};

export default CartPage;