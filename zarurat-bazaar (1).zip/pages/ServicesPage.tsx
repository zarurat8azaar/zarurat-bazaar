import React, { useState } from 'react';
import { SERVICES } from '../constants';
import { Calendar, CheckCircle, Clock } from 'lucide-react';
import { useApp } from '../services/store';

const ServicesPage = () => {
  const { user, toggleLoginModal } = useApp();
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toggleLoginModal(true);
      return;
    }
    // Simulate booking API call
    setTimeout(() => {
      setIsSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1000);
  };

  if (isSuccess) {
    return (
      <div className="container mx-auto px-4 py-20 text-center max-w-lg">
        <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle size={40} className="text-green-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Booking Confirmed!</h2>
        <p className="text-gray-600 mb-6">
          Your service request has been received. Our technician will call you shortly to confirm the address.
        </p>
        <button 
          onClick={() => { setIsSuccess(false); setSelectedService(null); }}
          className="bg-brand-green text-white px-6 py-2 rounded-lg hover:bg-brand-lightGreen"
        >
          Book Another Service
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-4">Professional Home Services</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          From verified electricians to expert plumbers, get things fixed at your home safely and quickly.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {SERVICES.map(service => (
          <div 
            key={service.id} 
            className={`bg-white rounded-2xl overflow-hidden border transition-all cursor-pointer ${selectedService === service.id ? 'border-brand-green ring-2 ring-brand-green ring-offset-2' : 'border-gray-200 hover:shadow-lg'}`}
            onClick={() => setSelectedService(service.id)}
          >
            <div className="h-48 overflow-hidden">
              <img src={service.image} alt={service.name} className="w-full h-full object-cover" />
            </div>
            <div className="p-6">
              <h3 className="font-bold text-xl mb-2">{service.name}</h3>
              <p className="text-gray-500 text-sm mb-4">{service.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-brand-green font-bold">Starts @ ₹{service.priceStart}</span>
                <button className={`px-4 py-2 rounded-lg text-sm font-medium ${selectedService === service.id ? 'bg-brand-green text-white' : 'bg-gray-100 text-gray-700'}`}>
                  {selectedService === service.id ? 'Selected' : 'Select'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedService && (
        <div className="mt-16 max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-lg border border-gray-100 animate-in slide-in-from-bottom-10 fade-in">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Calendar className="text-brand-green" /> Complete Booking
          </h3>
          <form onSubmit={handleBook} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Date</label>
                <input 
                  type="date" 
                  required 
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-brand-green"
                  onChange={(e) => setBookingDate(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Time Slot</label>
                <select className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-brand-green">
                  <option>Morning (9 AM - 12 PM)</option>
                  <option>Afternoon (12 PM - 4 PM)</option>
                  <option>Evening (4 PM - 8 PM)</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Problem Description (Optional)</label>
              <textarea 
                rows={3} 
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-brand-green"
                placeholder="Briefly describe the issue..."
              ></textarea>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg flex gap-3 text-sm text-blue-800">
               <Clock size={18} className="flex-shrink-0 mt-0.5"/>
               <p>A visiting charge of ₹99 is applicable if no service is availed after inspection.</p>
            </div>

            <button type="submit" className="w-full bg-brand-green hover:bg-brand-lightGreen text-white font-bold py-4 rounded-xl shadow-lg transition-transform active:scale-95">
              Confirm Booking
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ServicesPage;