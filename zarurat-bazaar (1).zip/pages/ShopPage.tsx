import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PRODUCTS, CATEGORIES } from '../constants';
import ProductCard from '../components/ProductCard';
import { Filter } from 'lucide-react';

const ShopPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('category') || 'all';
  const [priceRange, setPriceRange] = useState<number>(50000);

  const filteredProducts = PRODUCTS.filter(p => {
    const catMatch = activeCategory === 'all' || p.category === activeCategory;
    const priceMatch = p.price <= priceRange;
    return catMatch && priceMatch;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Filters */}
        <div className="w-full md:w-64 flex-shrink-0 space-y-6">
          <div className="bg-white p-4 rounded-xl border border-gray-100">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <Filter size={18} /> Filters
            </h3>
            
            <div className="mb-6">
              <h4 className="font-medium text-sm text-gray-700 mb-3">Categories</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button 
                    onClick={() => setSearchParams({})}
                    className={`w-full text-left px-2 py-1 rounded ${activeCategory === 'all' ? 'bg-brand-green/10 text-brand-green font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
                  >
                    All Products
                  </button>
                </li>
                {CATEGORIES.map(cat => (
                  <li key={cat.id}>
                    <button 
                      onClick={() => setSearchParams({ category: cat.slug })}
                      className={`w-full text-left px-2 py-1 rounded ${activeCategory === cat.slug ? 'bg-brand-green/10 text-brand-green font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
                    >
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-sm text-gray-700 mb-3">Max Price: ₹{priceRange}</h4>
              <input 
                type="range" 
                min="100" 
                max="50000" 
                step="500"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-green"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-2">
                <span>₹100</span>
                <span>₹50k+</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold capitalize">
              {activeCategory === 'all' ? 'All Products' : activeCategory.replace('-', ' ')}
            </h1>
            <span className="text-sm text-gray-500">{filteredProducts.length} results</span>
          </div>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-xl border border-dashed border-gray-300">
              <h3 className="text-lg font-medium text-gray-900">No products found</h3>
              <p className="text-gray-500">Try adjusting your filters.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShopPage;