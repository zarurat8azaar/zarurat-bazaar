import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu, Search, User as UserIcon, MapPin, X, LogOut, Phone } from 'lucide-react';
import { useApp } from '../services/store';
import { BRANCHES, CATEGORIES } from '../constants';
import AIChat from './AIChat';

const Navbar = () => {
  const { cart, user, selectedBranch, setBranch, toggleLoginModal, logout } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-brand-green text-white text-xs py-1 px-4 hidden md:flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <span className="flex items-center"><Phone size={12} className="mr-1" /> +91-11-23456789</span>
          <span>Malviya Nagar, New Delhi</span>
        </div>
        <div className="flex items-center space-x-4">
          <Link to="/admin" className="hover:text-brand-orange">Vendor Login</Link>
          <span className="cursor-pointer hover:text-brand-orange">Track Order</span>
        </div>
      </div>

      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo & Mobile Menu */}
          <div className="flex items-center gap-4">
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu size={24} className="text-gray-700" />
            </button>
            <Link to="/" className="text-2xl font-bold text-brand-green tracking-tight">
              Zarurat<span className="text-brand-orange">Bazaar</span>
            </Link>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 mx-8 relative">
            <input
              type="text"
              placeholder="Search for products, brands and more..."
              className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-brand-green"
            />
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-brand-green">
              <Search size={20} />
            </button>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-4 md:gap-6">
            {/* Branch Selector */}
            <div className="hidden md:flex flex-col items-end text-sm">
              <span className="text-gray-500 text-xs">Pickup Store</span>
              <select 
                value={selectedBranch?.id} 
                onChange={(e) => setBranch(BRANCHES.find(b => b.id === e.target.value) || BRANCHES[0])}
                className="font-medium text-brand-darkOrange bg-transparent focus:outline-none cursor-pointer"
              >
                {BRANCHES.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>

            {/* User */}
            {user ? (
              <div className="flex items-center gap-2 cursor-pointer group relative">
                <div className="bg-gray-100 p-2 rounded-full">
                  <UserIcon size={20} className="text-brand-green" />
                </div>
                <div className="hidden md:block">
                  <p className="text-xs text-gray-500">Hello,</p>
                  <p className="text-sm font-semibold truncate max-w-[100px]">{user.name.split(' ')[0]}</p>
                </div>
                {/* Dropdown */}
                <div className="absolute top-full right-0 mt-2 w-48 bg-white shadow-lg rounded-lg py-2 hidden group-hover:block border">
                  <Link to="/profile" className="block px-4 py-2 hover:bg-gray-50 text-sm">My Profile</Link>
                  <Link to="/orders" className="block px-4 py-2 hover:bg-gray-50 text-sm">Orders</Link>
                  <button onClick={logout} className="w-full text-left px-4 py-2 hover:bg-gray-50 text-sm text-red-500 flex items-center">
                    <LogOut size={14} className="mr-2" /> Logout
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={() => toggleLoginModal(true)}
                className="flex items-center gap-2 hover:text-brand-green"
              >
                <UserIcon size={24} />
                <span className="hidden md:inline font-medium">Login</span>
              </button>
            )}

            {/* Cart */}
            <Link to="/cart" className="relative hover:text-brand-green">
              <ShoppingCart size={24} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-brand-orange text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="mt-3 md:hidden relative">
          <input
            type="text"
            placeholder="Search products..."
            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg text-sm"
          />
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
        </div>
      </div>

      {/* Navigation Links */}
      <div className="bg-gray-100 border-b hidden md:block">
        <div className="container mx-auto px-4">
          <ul className="flex space-x-8 py-2 text-sm font-medium text-gray-700">
            {CATEGORIES.slice(0, 8).map(cat => (
              <Link key={cat.id} to={`/shop?category=${cat.slug}`} className="hover:text-brand-green transition-colors">
                {cat.name}
              </Link>
            ))}
          </ul>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50 md:hidden" onClick={() => setIsMenuOpen(false)}>
          <div className="bg-white w-3/4 h-full p-4" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <span className="font-bold text-xl text-brand-green">Menu</span>
              <button onClick={() => setIsMenuOpen(false)}><X size={24} /></button>
            </div>
            <ul className="space-y-4">
              <li><Link to="/" className="block py-2 border-b" onClick={() => setIsMenuOpen(false)}>Home</Link></li>
              <li><Link to="/shop" className="block py-2 border-b" onClick={() => setIsMenuOpen(false)}>Shop All</Link></li>
              <li><Link to="/services" className="block py-2 border-b" onClick={() => setIsMenuOpen(false)}>Book Services</Link></li>
              <li><Link to="/branches" className="block py-2 border-b" onClick={() => setIsMenuOpen(false)}>Store Locator</Link></li>
            </ul>
          </div>
        </div>
      )}
    </nav>
  );
};

const Footer = () => (
  <footer className="bg-gray-900 text-gray-300 py-10">
    <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
      <div>
        <h3 className="text-white text-xl font-bold mb-4">Zarurat Bazaar</h3>
        <p className="text-sm mb-4">A subsidiary of Yaqoobi Empire Pvt. Ltd.</p>
        <p className="text-sm flex items-start gap-2">
          <MapPin size={16} className="mt-1 flex-shrink-0" />
          Malviya Nagar, New Delhi, 110017, India.
        </p>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Quick Links</h4>
        <ul className="space-y-2 text-sm">
          <li><Link to="/shop" className="hover:text-brand-orange">Products</Link></li>
          <li><Link to="/services" className="hover:text-brand-orange">Services</Link></li>
          <li><Link to="/about" className="hover:text-brand-orange">About Us</Link></li>
          <li><Link to="/contact" className="hover:text-brand-orange">Contact Support</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Categories</h4>
        <ul className="space-y-2 text-sm">
          <li><Link to="/shop?category=groceries" className="hover:text-brand-orange">Groceries</Link></li>
          <li><Link to="/shop?category=electronics" className="hover:text-brand-orange">Electronics</Link></li>
          <li><Link to="/shop?category=clothing" className="hover:text-brand-orange">Fashion</Link></li>
          <li><Link to="/shop?category=furniture" className="hover:text-brand-orange">Furniture (New & Used)</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Newsletter</h4>
        <p className="text-sm mb-4">Subscribe to get special offers and updates.</p>
        <div className="flex">
          <input type="email" placeholder="Email address" className="bg-gray-800 text-white px-4 py-2 rounded-l-lg w-full focus:outline-none" />
          <button className="bg-brand-green px-4 py-2 rounded-r-lg hover:bg-brand-lightGreen">Subscribe</button>
        </div>
      </div>
    </div>
    <div className="border-t border-gray-800 mt-10 pt-6 text-center text-sm">
      &copy; {new Date().getFullYear()} Zarurat Bazaar. All rights reserved.
    </div>
  </footer>
);

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      <AIChat />
    </div>
  );
};

export default Layout;