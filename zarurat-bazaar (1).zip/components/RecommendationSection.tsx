import React, { useEffect, useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { Product } from '../types';
import { PRODUCTS } from '../constants';
import ProductCard from './ProductCard';
import { getProductRecommendations } from '../services/geminiService';

interface RecommendationSectionProps {
  title?: string;
  context: string;
  excludeIds?: string[];
}

const RecommendationSection: React.FC<RecommendationSectionProps> = ({ 
  title = "Recommended for You", 
  context,
  excludeIds = []
}) => {
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const fetchRecommendations = async () => {
      if (loaded) return;
      setLoading(true);
      try {
        const ids = await getProductRecommendations(context, excludeIds);
        const products = PRODUCTS.filter(p => ids.includes(p.id));
        setRecommendations(products);
      } catch (error) {
        console.error("Failed to load recommendations", error);
      } finally {
        setLoading(false);
        setLoaded(true);
      }
    };

    // Intersection Observer could be used here for lazy loading, 
    // but for now we fetch on mount.
    fetchRecommendations();
  }, [context, excludeIds, loaded]);

  if (!loading && recommendations.length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-green-50 to-orange-50 rounded-2xl p-6 md:p-8 border border-white shadow-sm my-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-white p-2 rounded-full shadow-sm text-brand-orange">
          <Sparkles size={24} />
        </div>
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-sm text-gray-500">AI-Curated picks based on your preferences</p>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-gray-400">
          <Loader2 size={32} className="animate-spin mb-2" />
          <p className="text-sm">Personalizing your feed...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-in slide-in-from-bottom-4 fade-in duration-500">
          {recommendations.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default RecommendationSection;