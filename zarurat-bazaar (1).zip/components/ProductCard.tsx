import React from 'react';
import { ShoppingCart, Star, RefreshCw } from 'lucide-react';
import { Product } from '../types';
import { useApp } from '../services/store';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useApp();

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden group">
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {(product.isNew) && (
          <span className="absolute top-2 left-2 bg-brand-green text-white text-[10px] font-bold px-2 py-1 rounded">NEW</span>
        )}
        {(product.isUsed) && (
          <span className="absolute top-2 left-2 bg-brand-orange text-white text-[10px] font-bold px-2 py-1 rounded">USED</span>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-center gap-1 mb-2">
          <Star size={14} className="fill-yellow-400 text-yellow-400" />
          <span className="text-xs font-medium text-gray-500">{product.rating} ({product.reviews})</span>
        </div>
        
        <h3 className="font-semibold text-gray-800 text-sm mb-1 truncate">{product.name}</h3>
        <p className="text-xs text-gray-500 mb-3 capitalize">{product.category}</p>
        
        <div className="flex items-end justify-between">
          <div>
            <span className="text-lg font-bold text-gray-900">₹{product.price}</span>
            {product.originalPrice && (
              <span className="text-xs text-gray-400 line-through ml-2">₹{product.originalPrice}</span>
            )}
          </div>
          
          <button 
            onClick={() => addToCart(product)}
            className="bg-gray-100 hover:bg-brand-green hover:text-white text-gray-800 p-2 rounded-lg transition-colors"
            title="Add to Cart"
          >
            <ShoppingCart size={18} />
          </button>
        </div>
        
        {/* Features badges */}
        <div className="mt-3 flex gap-2">
           {product.category === 'electronics' && <div className="text-[10px] flex items-center gap-1 text-gray-500 bg-gray-50 px-2 py-1 rounded"><RefreshCw size={10}/> EMI Avail</div>}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;