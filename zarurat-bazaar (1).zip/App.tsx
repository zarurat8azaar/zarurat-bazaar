import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './services/store';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ServicesPage from './pages/ServicesPage';
import CartPage from './pages/CartPage';
import AdminDashboard from './pages/AdminDashboard';
import { X } from 'lucide-react';

const LoginModal = () => {
  const { isLoginModalOpen, toggleLoginModal, login } = useApp();
  const [email, setEmail] = React.useState('');

  if (!isLoginModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-md rounded-2xl p-8 relative shadow-2xl animate-in fade-in zoom-in duration-200">
        <button 
          onClick={() => toggleLoginModal(false)}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X size={24} />
        </button>
        
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Welcome Back</h2>
          <p className="text-gray-500 text-sm mt-2">Login to manage orders and bookings</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email or Phone</label>
            <input 
              type="text" 
              required
              className="w-full px-4 py-3 rounded-lg border focus:outline-none focus:border-brand-green bg-gray-50"
              placeholder="user@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          
          <button className="w-full bg-brand-green text-white py-3 rounded-lg font-bold hover:bg-brand-lightGreen shadow-lg">
            Send OTP
          </button>
        </form>

        <p className="text-center text-xs text-gray-400 mt-6">
          By continuing, you agree to Zarurat Bazaar's Terms of Service.
        </p>
      </div>
    </div>
  );
};

const AppRoutes = () => {
  return (
    <>
      <LoginModal />
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/shop" element={<ShopPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </>
  );
};

const App = () => {
  return (
    <AppProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AppProvider>
  );
};

export default App;