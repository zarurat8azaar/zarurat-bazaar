export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isUsed?: boolean;
  stock: number;
  description: string;
}

export interface Service {
  id: string;
  name: string;
  category: string;
  priceStart: number;
  image: string;
  description: string;
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  coordinates: { lat: number; lng: number };
  phone: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'admin' | 'vendor';
  addresses: Address[];
}

export interface Address {
  id: string;
  label: string; // e.g., Home, Work
  details: string;
}

export type Category = {
  id: string;
  name: string;
  icon: string;
  slug: string;
};

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}